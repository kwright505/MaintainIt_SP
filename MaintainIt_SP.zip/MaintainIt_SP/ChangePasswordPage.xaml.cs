﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MaintainIt_SP
{
    public partial class ChangePasswordPage : ContentPage
    {
        public ChangePasswordPage()
        {
            InitializeComponent();
        }
    }
}
