﻿using System;
namespace MaintainIt_SP
{
    public interface ILocalFileHelper
    {
        string GetLocalFilePath(string filename);
    }
}
