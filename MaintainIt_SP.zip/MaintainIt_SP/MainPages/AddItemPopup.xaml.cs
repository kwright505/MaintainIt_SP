﻿using System;
using MaintainIt_SP.Services;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MaintainIt_SP.MainPages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddItemPopup
    {
        public AddItemPopup(int loc)
        {
            InitializeComponent();

            switch (loc)
            {
                case 0:
                    Location.SelectedIndex = 0;
                    break;
                case 1:
                    Location.SelectedIndex = 1;
                    break;
                default:
                    Console.WriteLine("sorry bout that");
                    break;
            }

        }

        public int checkDone;

        private async void ExitClicked(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PopAsync(true);
                    
        }

        public ItemInstance NewItemDet = new ItemInstance();

        public void SaveItem()
        {
            ItemInstance itemInstance = new ItemInstance
            {
                Location = Location.SelectedItem.ToString(),
                //ItemType = ItemType.SelectedItem.ToString(),
                //Manufacturer = Manufacturer.ToString(),
                ItemName = ItemName.Text,
                ItemDesc = ItemDesc.Text,
                DatePurchased = DatePurchased.Date
            };

            NewItemDet = itemInstance;
        }

        public void ClearItem()
        {
            ItemType.SelectedItem = null;
            Manufacturer.SelectedItem = null;
            ItemName.Text = "";
            ItemDesc.Text = "";
            DatePurchased.Date = DateTime.Today;
        }

        public EventHandler NewItemSave;
        private async void AddClicked(object sender, EventArgs e)
        {
            SaveItem();

            EventHandler handler = NewItemSave;
            handler?.Invoke(this, e);
            ClearItem();

            await DisplayAlert("New Item!", "Created new Item", "OK");
            await PopupNavigation.Instance.PopAsync(true);


        }

    }
}