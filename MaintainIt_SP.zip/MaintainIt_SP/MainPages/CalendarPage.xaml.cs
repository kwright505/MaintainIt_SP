﻿using System;
using System.Collections.Generic;
using Syncfusion.SfCalendar.XForms;

using Xamarin.Forms;

namespace MaintainIt_SP.MainPages
{
    public partial class CalendarPage : ContentPage
    {
        public CalendarPage()
        {
            InitializeComponent();
        }
    }
}
