﻿using System;
using System.Collections.Generic;
using MaintainIt_SP.Services;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;

namespace MaintainIt_SP.MainPages
{
    public partial class ItemDetailsPopup
    {
        public ItemDetailsPopup(ItemInstance item)
        {
            InitializeComponent();

            Location.SelectedItem = item.Location;
            //ItemType.SelectedItem = item.ItemType;
            //Manufacturer.SelectedItem = item.Manufacturer;
            ItemName.Text = item.ItemName;
            ItemDesc.Text = item.ItemDesc;
            DatePurchased.Date = item.DatePurchased.Date;
        }

        public ItemInstance UpdatedItemDet;

        public void SaveItem()
        {
            ItemInstance itemInstance = new ItemInstance();
            itemInstance.Location = Location.SelectedItem.ToString();
            //itemInstance.ItemType = ItemType.SelectedItem.ToString();
            //itemInstance.Manufacturer = Manufacturer.ToString();
            itemInstance.ItemName = ItemName.Text;
            itemInstance.ItemDesc = ItemDesc.Text;
            UpdatedItemDet = itemInstance;
        }


        private async void ExitClicked(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PopAsync(true);

        }

        public EventHandler UpdateItem;
        private async void SaveClicked(object sender, EventArgs e)
        {
            SaveItem();

            EventHandler handler = UpdateItem;
            handler?.Invoke(this, e);

            await PopupNavigation.Instance.PopAsync(true);

        }

    }
}
