﻿using System;
using System.Collections.Generic;
using MaintainIt_SP.Services;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;

namespace MaintainIt_SP.MainPages
{
    public partial class CarPopup
    {
        public CarPopup()
        {
            InitializeComponent();
            ItemType.SelectedItem = "Car";
        }

        private async void ExitClicked(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PopAsync(true);

        }

        public CarInstance NewCarDet;

        public void SaveItem()
        {
            CarInstance carInstance = new CarInstance
            {
                ItemType = ItemType.SelectedItem.ToString(),
                VIN = VINNumber.Text,
                Manufacturer = Manufacturer.SelectedItem.ToString(),
                Model = Model.Text,
                Year = Year.Text,
                DatePurchaced = DatePurchased.Date
            };

            NewCarDet = carInstance;
        }

        public EventHandler NewItemSave;
        private async void AddClicked(object sender, EventArgs e)
        {
            SaveItem();

            EventHandler handler = NewItemSave;
            handler?.Invoke(this, e);

            await PopupNavigation.Instance.PopAsync(true);

        }


    }
}
