﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MaintainIt_SP.MainPages
{
    public partial class DocumentPage : ContentPage
    {
        public DocumentPage()
        {
            InitializeComponent();
        }
    }
}
