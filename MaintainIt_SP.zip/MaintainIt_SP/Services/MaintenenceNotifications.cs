﻿using System;
using Plugin.LocalNotifications;

namespace MaintainIt_SP.Services
{
    public class MaintenenceNotifications
    {
        public MaintenenceNotifications()
        {
        }


        public void NewNotification(ItemInstance item)
        {
            //CrossLocalNotifications.Current.Show("MaintainIt Maintenance Re);
        }

        public void TestNotification()
        {
            CrossLocalNotifications.Current.Show("MaintainIt Maintenance Reminder", 
                "Thanks for Chosing MaintainIt!", 101, DateTime.Now.AddSeconds(5));
        }
    }
}
