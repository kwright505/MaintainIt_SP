﻿using System;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace MaintainIt_SP.Services
{
    public class VINDecode
    {
        public string VINNumDecode(string VIN)
        {
            {
                var request = WebRequest.Create(@"https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/" + VIN + @"?format=json");
                request.ContentType = "application/json";
                request.Method = "GET";

                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        return "Status code bad!";

                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        var content = reader.ReadToEnd();
                        if (string.IsNullOrWhiteSpace(content))
                            return "response string invalid";
                        else
                        {
                            Console.WriteLine("Response : " + content);

                            var newVerses = JsonConvert.DeserializeObject<CarInstance>(content);

                            return content;

                        }
                    }
                }
            }
        }
    }
}